import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatRelativeDate(date: string) {
  return new Intl.DateTimeFormat("en", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit"
  }).format(new Date(date));
}

export function isUnlimitedPlan(status?: string | null) {
  return status === "active" || status === "trialing";
}

export function buildCopyBlock(hook: string, caption: string, hashtags: string[]) {
  return `${hook}\n\n${caption}\n\n${hashtags.join(" ")}`;
}

export function getInitials(name?: string | null) {
  if (!name) return "RF";
  return name
    .split(" ")
    .map((chunk) => chunk[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export function getTodayKey() {
  return new Date().toISOString().slice(0, 10);
}
