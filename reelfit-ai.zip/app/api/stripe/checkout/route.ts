import { NextRequest, NextResponse } from "next/server";

import { getSupabaseAdminClient } from "@/lib/supabase/admin";
import { getStripeClient } from "@/lib/stripe";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const stripe = getStripeClient();
  const supabase = getSupabaseAdminClient();
  const priceId = process.env.STRIPE_PRICE_ID;

  if (!stripe || !supabase || !priceId) {
    return NextResponse.json(
      { message: "Stripe checkout is not configured. Add Stripe and Supabase env vars first." },
      { status: 500 }
    );
  }

  const body = (await request.json()) as {
    userId?: string;
    email?: string;
    origin?: string;
  };

  if (!body.userId) {
    return NextResponse.json({ message: "Missing user ID." }, { status: 400 });
  }

  const accessToken = request.headers.get("authorization")?.replace("Bearer ", "");
  if (!accessToken) {
    return NextResponse.json({ message: "Missing auth session." }, { status: 401 });
  }

  const {
    data: { user },
    error: authError
  } = await supabase.auth.getUser(accessToken);

  if (authError || !user || user.id !== body.userId) {
    return NextResponse.json({ message: "Unauthorized checkout request." }, { status: 401 });
  }

  const origin = body.origin || request.nextUrl.origin;
  const { data: userProfile } = await supabase.from("users").select("*").eq("user_id", body.userId).maybeSingle();
  let customerId = userProfile?.stripe_customer_id ?? null;

  if (!customerId) {
    const customer = await stripe.customers.create({
      email: body.email ?? userProfile?.email ?? undefined,
      metadata: {
        supabaseUserId: body.userId
      }
    });
    customerId = customer.id;

    await supabase.from("users").upsert(
      {
        user_id: body.userId,
        email: body.email ?? userProfile?.email ?? null,
        stripe_customer_id: customerId,
        subscription_status: userProfile?.subscription_status ?? "free",
        generation_count: userProfile?.generation_count ?? 0,
        generation_date: userProfile?.generation_date ?? new Date().toISOString().slice(0, 10)
      },
      { onConflict: "user_id" }
    );
  }

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: customerId,
    client_reference_id: body.userId,
    allow_promotion_codes: true,
    billing_address_collection: "auto",
    line_items: [
      {
        price: priceId,
        quantity: 1
      }
    ],
    success_url: `${origin}/?checkout=success`,
    cancel_url: `${origin}/?checkout=canceled`,
    subscription_data: {
      metadata: {
        supabaseUserId: body.userId
      }
    },
    metadata: {
      supabaseUserId: body.userId
    }
  });

  return NextResponse.json({ url: session.url });
}
