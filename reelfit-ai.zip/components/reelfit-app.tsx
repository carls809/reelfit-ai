"use client";

import { startTransition, useEffect, useMemo, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { motion, useReducedMotion } from "framer-motion";
import {
  CheckCircle2,
  ChevronRight,
  CopyCheck,
  CreditCard,
  Loader2,
  LogOut,
  Sparkles,
  WandSparkles
} from "lucide-react";
import { toast } from "sonner";

import { AuthDialog } from "@/components/auth-dialog";
import { BrandMark } from "@/components/brand-mark";
import { HistorySidebar } from "@/components/history-sidebar";
import { ModeToggle } from "@/components/mode-toggle";
import { PricingPill } from "@/components/pricing-pill";
import { ReelCard } from "@/components/reel-card";
import { SiteFooter } from "@/components/site-footer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DURATION_OPTIONS, FREE_DAILY_LIMIT, GOAL_OPTIONS, PREMIUM_PRICE, STYLE_OPTIONS } from "@/lib/constants";
import { createGenerationPayload, createGenerationRecord } from "@/lib/ai";
import { getSupabaseBrowserClient } from "@/lib/supabase/client";
import type {
  DurationValue,
  GenerateIdeasResponse,
  GenerationPayload,
  GenerationRecord,
  GoalValue,
  ReelIdea,
  StyleValue,
  UserProfile
} from "@/lib/types";
import { buildCopyBlock, getInitials, getTodayKey, isUnlimitedPlan } from "@/lib/utils";
import { useLocalStorage } from "@/hooks/use-local-storage";

const INITIAL_SAMPLE_HISTORY: GenerationRecord[] = [
  createGenerationRecord(createGenerationPayload("weight-loss", "motivational", "15s"), {
    id: "sample-history-1",
    saved: true,
    source: "local"
  }),
  createGenerationRecord(createGenerationPayload("home-workouts", "funny", "30s"), {
    id: "sample-history-2",
    saved: true,
    source: "local"
  })
];

function mapPayloadToRecord(row: {
  id: string;
  goal: GoalValue;
  style: StyleValue;
  duration: DurationValue;
  payload: GenerationPayload;
  created_at: string;
}): GenerationRecord {
  return {
    id: row.id,
    goal: row.goal ?? row.payload.goal,
    style: row.style ?? row.payload.style,
    duration: row.duration ?? row.payload.duration,
    ideas: row.payload.ideas,
    createdAt: row.created_at ?? row.payload.generatedAt,
    summary: `${GOAL_OPTIONS.find((option) => option.value === row.goal)?.label ?? row.goal} • ${
      STYLE_OPTIONS.find((option) => option.value === row.style)?.label ?? row.style
    } • ${row.duration}`,
    saved: true,
    source: "supabase"
  };
}

export function ReelFitApp() {
  const supabase = useMemo(() => getSupabaseBrowserClient(), []);
  const reduceMotion = useReducedMotion();

  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [form, setForm] = useState<{
    goal: GoalValue;
    style: StyleValue;
    duration: DurationValue;
  }>({
    goal: "weight-loss",
    style: "motivational",
    duration: "15s"
  });
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [loadingGenerate, setLoadingGenerate] = useState(false);
  const [billingLoading, setBillingLoading] = useState(false);
  const [currentRecord, setCurrentRecord] = useState<GenerationRecord | null>(INITIAL_SAMPLE_HISTORY[0]);
  const [history, setHistory] = useState<GenerationRecord[]>(INITIAL_SAMPLE_HISTORY);

  const guestHistoryState = useLocalStorage<GenerationRecord[]>("reelfit-guest-history", INITIAL_SAMPLE_HISTORY);
  const guestUsageState = useLocalStorage<{ date: string; count: number }>("reelfit-guest-usage", {
    date: getTodayKey(),
    count: 0
  });
  const guestUsageDate = guestUsageState.value.date;
  const setGuestUsage = guestUsageState.setValue;

  const isUnlimited = isUnlimitedPlan(profile?.subscription_status);
  const guestUsageCount =
    guestUsageDate === getTodayKey() ? guestUsageState.value.count : 0;
  const remaining = isUnlimited
    ? null
    : Math.max(
        0,
        FREE_DAILY_LIMIT -
          (user ? profile?.generation_count ?? 0 : guestUsageCount)
      );

  const goalLabel = GOAL_OPTIONS.find((option) => option.value === form.goal)?.label ?? "your goal";
  const styleLabel = STYLE_OPTIONS.find((option) => option.value === form.style)?.label ?? "motivational";

  useEffect(() => {
    if (guestUsageDate !== getTodayKey()) {
      setGuestUsage({ date: getTodayKey(), count: 0 });
    }
  }, [guestUsageDate, setGuestUsage]);

  useEffect(() => {
    if (!supabase) return;

    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user ?? null);
    });

    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (!session?.user) {
        setProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, [supabase]);

  useEffect(() => {
    if (user || !guestHistoryState.ready) return;

    startTransition(() => {
      setHistory(guestHistoryState.value);
      setCurrentRecord((previous) => {
        if (previous && guestHistoryState.value.some((item) => item.id === previous.id)) {
          return previous;
        }
        return guestHistoryState.value[0] ?? null;
      });
    });
  }, [guestHistoryState.ready, guestHistoryState.value, user]);

  useEffect(() => {
    if (!supabase || !user) return;
    const activeUser = user;
    const activeSupabase = supabase;

    let active = true;

    async function loadUserData() {
      const bootstrapProfile = {
        user_id: activeUser.id,
        email: activeUser.email ?? null,
        full_name:
          activeUser.user_metadata?.full_name ??
          activeUser.user_metadata?.name ??
          activeUser.email?.split("@")[0] ??
          "Coach",
        avatar_url: activeUser.user_metadata?.avatar_url ?? null,
        subscription_status: "free",
        generation_count: 0,
        generation_date: getTodayKey(),
        stripe_customer_id: null,
        stripe_subscription_id: null
      };

      const [{ data: profileRow, error: profileError }, { data: historyRows, error: historyError }] =
        await Promise.all([
          activeSupabase.from("users").upsert(bootstrapProfile, { onConflict: "user_id" }).select().single(),
          activeSupabase
            .from("ideas")
            .select("id, goal, style, duration, payload, created_at")
            .order("created_at", { ascending: false })
            .limit(10)
        ]);

      if (!active) return;

      if (profileError) {
        toast.error(profileError.message);
      } else {
        setProfile(profileRow as UserProfile);
      }

      if (historyError) {
        toast.error(historyError.message);
      } else if (historyRows && historyRows.length > 0) {
        const mapped = historyRows.map((row) =>
          mapPayloadToRecord(
            row as {
              id: string;
              goal: GoalValue;
              style: StyleValue;
              duration: DurationValue;
              payload: GenerationPayload;
              created_at: string;
            }
          )
        );

        startTransition(() => {
          setHistory(mapped);
          setCurrentRecord(mapped[0]);
        });
      } else {
        setHistory(INITIAL_SAMPLE_HISTORY);
        setCurrentRecord(INITIAL_SAMPLE_HISTORY[0]);
      }
    }

    void loadUserData();

    return () => {
      active = false;
    };
  }, [supabase, user]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const checkoutState = params.get("checkout");
    if (!checkoutState) return;

    if (checkoutState === "success") {
      toast.success("Subscription updated. Your unlimited plan should be ready.");
    } else if (checkoutState === "canceled") {
      toast.message("Checkout canceled. Your free plan is still active.");
    }

    params.delete("checkout");
    const nextQuery = params.toString();
    window.history.replaceState({}, "", nextQuery ? `/?${nextQuery}` : "/");
  }, []);

  async function requestGenerate(nextForm = form) {
    if (!isUnlimited && !user && guestUsageCount >= FREE_DAILY_LIMIT) {
      toast.error("You’ve used all 3 free generations today. Upgrade for unlimited.");
      return;
    }

    setLoadingGenerate(true);

    try {
      const accessToken = user && supabase ? (await supabase.auth.getSession()).data.session?.access_token : null;
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {})
        },
        body: JSON.stringify(nextForm)
      });

      const payload = (await response.json()) as GenerateIdeasResponse & { message?: string };

      if (!response.ok) {
        if (payload.limitReached) {
          toast.error("You’ve hit today’s free limit. Upgrade for unlimited generations.");
        } else {
          toast.error(payload.message ?? "Unable to generate ideas right now.");
        }
        return;
      }

      startTransition(() => {
        setCurrentRecord(payload.record);
        setHistory((previous) => [payload.record, ...previous.filter((item) => item.id !== payload.record.id)].slice(0, 10));
      });

      if (user) {
        setProfile((previous) =>
          previous
            ? {
                ...previous,
                subscription_status: payload.subscriptionStatus,
                generation_count: payload.remaining === null ? previous.generation_count : FREE_DAILY_LIMIT - payload.remaining,
                generation_date: getTodayKey()
              }
            : previous
        );
      } else {
        guestUsageState.setValue({ date: getTodayKey(), count: guestUsageCount + 1 });
        guestHistoryState.setValue(([
          payload.record,
          ...guestHistoryState.value.filter((item) => item.id !== payload.record.id)
        ]).slice(0, 10));
      }

      toast.success("Fresh Reel ideas are ready.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Something went wrong.");
    } finally {
      setLoadingGenerate(false);
    }
  }

  async function persistFavorite(nextRecord: GenerationRecord) {
    if (!user || !supabase || nextRecord.source !== "supabase") return;

    const { error } = await supabase
      .from("ideas")
      .update({
        payload: {
          goal: nextRecord.goal,
          style: nextRecord.style,
          duration: nextRecord.duration,
          ideas: nextRecord.ideas,
          generatedAt: nextRecord.createdAt
        }
      })
      .eq("id", nextRecord.id);

    if (error) {
      toast.error("Favorite sync failed.");
    }
  }

  function handleToggleFavorite(ideaId: string) {
    if (!currentRecord) return;

    const nextIdeas = currentRecord.ideas.map((idea) =>
      idea.id === ideaId ? { ...idea, favorite: !idea.favorite } : idea
    );
    const nextRecord = { ...currentRecord, ideas: nextIdeas };

    setCurrentRecord(nextRecord);
    setHistory((previous) => previous.map((item) => (item.id === nextRecord.id ? nextRecord : item)));

    if (!user) {
      guestHistoryState.setValue(
        guestHistoryState.value.map((item) => (item.id === nextRecord.id ? nextRecord : item))
      );
    } else {
      void persistFavorite(nextRecord);
    }
  }

  function handleSelectHistory(record: GenerationRecord) {
    setForm({
      goal: record.goal,
      style: record.style,
      duration: record.duration
    });
    setCurrentRecord(record);
  }

  async function handleCopyIdea(idea: ReelIdea) {
    await navigator.clipboard.writeText(buildCopyBlock(idea.hook, idea.caption, idea.hashtags));
    toast.success("Copied Reel package to clipboard.");
  }

  function handleSaveIdea() {
    toast.success("This generation is already saved to history.");
  }

  async function handleUpgrade() {
    if (!user) {
      setAuthDialogOpen(true);
      toast.message("Create a free account first so Stripe can attach billing to your profile.");
      return;
    }

    setBillingLoading(true);

    try {
      const accessToken = supabase ? (await supabase.auth.getSession()).data.session?.access_token : null;
      const response = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {})
        },
        body: JSON.stringify({
          userId: user.id,
          email: user.email,
          origin: window.location.origin
        })
      });

      const payload = (await response.json()) as { url?: string; message?: string };

      if (!response.ok || !payload.url) {
        throw new Error(payload.message ?? "Stripe checkout is not configured.");
      }

      window.location.href = payload.url;
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to open checkout.");
    } finally {
      setBillingLoading(false);
    }
  }

  async function handleManageBilling() {
    if (!user) {
      setAuthDialogOpen(true);
      return;
    }

    setBillingLoading(true);

    try {
      const accessToken = supabase ? (await supabase.auth.getSession()).data.session?.access_token : null;
      const response = await fetch("/api/stripe/portal", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {})
        },
        body: JSON.stringify({
          userId: user.id,
          origin: window.location.origin
        })
      });

      const payload = (await response.json()) as { url?: string; message?: string };

      if (!response.ok || !payload.url) {
        throw new Error(payload.message ?? "Stripe customer portal is not ready yet.");
      }

      window.location.href = payload.url;
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to open billing portal.");
    } finally {
      setBillingLoading(false);
    }
  }

  async function handleSignOut() {
    if (!supabase) return;
    await supabase.auth.signOut();
    toast.success("Signed out. Guest mode is still available.");
  }

  const heroPreview = `Enter your goal → Get 5 ${goalLabel.toLowerCase()} ${styleLabel.toLowerCase()} ideas instantly`;
  const generateLabel = loadingGenerate
    ? "Generating ideas..."
    : `Generate 5 ${goalLabel.toLowerCase()} ideas`;

  return (
    <div className="relative">
      <PricingPill
        isUnlimited={isUnlimited}
        remaining={remaining}
        onUpgrade={handleUpgrade}
        onManageBilling={handleManageBilling}
      />

      <AuthDialog open={authDialogOpen} onOpenChange={setAuthDialogOpen} />

      <div className="container space-y-8 pb-10 pt-5 md:pt-8">
        <header className="flex items-center justify-between gap-4">
          <BrandMark />
          <div className="flex items-center gap-2">
            <ModeToggle />
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="rounded-full px-3">
                    <span className="mr-3 grid h-8 w-8 place-items-center rounded-full bg-primary/12 text-sm font-semibold text-primary">
                      {getInitials(profile?.full_name ?? user.email)}
                    </span>
                    <span className="hidden sm:inline">{profile?.full_name ?? user.email?.split("@")[0]}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>Signed in as {user.email}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleManageBilling}>
                    <CreditCard className="mr-2 h-4 w-4" />
                    Billing portal
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleSignOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="outline" onClick={() => setAuthDialogOpen(true)}>
                Sign in
              </Button>
            )}
          </div>
        </header>

        <section className="section-shell overflow-hidden px-6 py-8 md:px-10 md:py-12">
          <div className="absolute inset-0 bg-grid-fade bg-grid opacity-60" />
          <div className="absolute -left-10 top-10 h-44 w-44 rounded-full bg-primary/20 blur-3xl" />
          <div className="absolute right-0 top-0 h-56 w-56 rounded-full bg-secondary/20 blur-3xl" />

          <div className="relative grid items-center gap-8 lg:grid-cols-[1.15fr_0.85fr]">
            <motion.div
              initial={reduceMotion ? false : { opacity: 0, y: 18 }}
              animate={reduceMotion ? undefined : { opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
              className="space-y-6"
            >
              <Badge className="w-fit">Built for fitness coaches</Badge>
              <div className="space-y-4">
                <h1 className="max-w-4xl balance font-hero text-[4rem] font-semibold leading-[0.95] text-shadow-soft lg:text-[6rem]">
                  Generate Viral Fitness Reels in Seconds
                </h1>
                <p className="max-w-2xl text-lg text-muted-foreground md:text-xl">
                  AI crafts hooks, captions, and hashtags for your niche so you can go from blank page to post-ready in one click.
                </p>
              </div>

              <div className="inline-flex max-w-full items-center gap-3 rounded-full border border-primary/20 bg-primary/10 px-5 py-3 text-sm font-semibold text-primary shadow-sm dark:bg-primary/15">
                <Sparkles className="h-4 w-4 shrink-0" />
                <span className="truncate">{heroPreview}</span>
                <ChevronRight className="h-4 w-4 shrink-0" />
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                {[
                  { label: "Flow", value: "1-click" },
                  { label: "Free tier", value: "3 / day" },
                  { label: "Plan", value: PREMIUM_PRICE }
                ].map((item) => (
                  <div key={item.label} className="rounded-[1.5rem] border border-white/60 bg-white/70 p-4 backdrop-blur-xl dark:border-white/10 dark:bg-zinc-950/55">
                    <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">{item.label}</p>
                    <p className="mt-2 text-2xl font-semibold">{item.value}</p>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={reduceMotion ? false : { opacity: 0, y: 20 }}
              animate={reduceMotion ? undefined : { opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.08 }}
              className="grid gap-4 sm:grid-cols-2"
            >
              <Card className="sm:col-span-2 bg-background/80">
                <CardHeader className="pb-4">
                  <Badge className="w-fit">One-screen workflow</Badge>
                  <CardTitle className="text-3xl">Dial in goal, tone, and length.</CardTitle>
                  <CardDescription>Everything stays on the same page for fast ideation on mobile and desktop.</CardDescription>
                </CardHeader>
              </Card>
              <Card className="bg-background/80">
                <CardContent className="p-6">
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Output</p>
                  <p className="mt-2 text-xl font-semibold">5 Reel cards</p>
                  <p className="mt-2 text-sm text-muted-foreground">Hook, caption, hashtags, thumbnail placeholder, copy CTA.</p>
                </CardContent>
              </Card>
              <Card className="bg-background/80">
                <CardContent className="p-6">
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Retention</p>
                  <p className="mt-2 text-xl font-semibold">Saved history</p>
                  <p className="mt-2 text-sm text-muted-foreground">Last 10 generations plus favorites for easy re-use.</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        <section className="grid gap-6 xl:grid-cols-[320px_minmax(0,1fr)]">
          <HistorySidebar
            history={history}
            activeId={currentRecord?.id ?? null}
            remaining={remaining}
            isUnlimited={isUnlimited}
            isSignedIn={Boolean(user)}
            onSelect={handleSelectHistory}
            onRegenerate={(record) => {
              const nextForm = { goal: record.goal, style: record.style, duration: record.duration };
              setForm(nextForm);
              void requestGenerate(nextForm);
            }}
            onUpgrade={handleUpgrade}
            onManageBilling={handleManageBilling}
          />

          <div className="space-y-6">
            <Card className="overflow-hidden">
              <CardHeader className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Generator</p>
                    <CardTitle className="mt-2 text-3xl">Enter your goal and generate instantly</CardTitle>
                  </div>
                  <Badge variant={isUnlimited ? "default" : "secondary"}>
                    {isUnlimited ? "Unlimited active" : `${remaining ?? 0} free generations left today`}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="mx-auto grid max-w-[500px] gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold" htmlFor="goal-select">
                      Goal
                    </label>
                    <Select
                      value={form.goal}
                      onValueChange={(value) => setForm((previous) => ({ ...previous, goal: value as GoalValue }))}
                    >
                      <SelectTrigger id="goal-select" aria-label="Choose your content goal">
                        <SelectValue placeholder="Choose a goal" />
                      </SelectTrigger>
                      <SelectContent>
                        {GOAL_OPTIONS.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-semibold" htmlFor="style-select">
                      Style
                    </label>
                    <Select
                      value={form.style}
                      onValueChange={(value) => setForm((previous) => ({ ...previous, style: value as StyleValue }))}
                    >
                      <SelectTrigger id="style-select" aria-label="Choose the Reel style">
                        <SelectValue placeholder="Choose a style" />
                      </SelectTrigger>
                      <SelectContent>
                        {STYLE_OPTIONS.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-semibold" htmlFor="duration-select">
                      Duration
                    </label>
                    <Select
                      value={form.duration}
                      onValueChange={(value) => setForm((previous) => ({ ...previous, duration: value as DurationValue }))}
                    >
                      <SelectTrigger id="duration-select" aria-label="Choose the Reel duration">
                        <SelectValue placeholder="Choose a duration" />
                      </SelectTrigger>
                      <SelectContent>
                        {DURATION_OPTIONS.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Button className="h-14 rounded-2xl text-base" onClick={() => void requestGenerate()} disabled={loadingGenerate}>
                    {loadingGenerate ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Loading ideas
                      </>
                    ) : (
                      <>
                        <WandSparkles className="mr-2 h-5 w-5" />
                        {generateLabel}
                      </>
                    )}
                  </Button>
                </div>

                {!isUnlimited && remaining === 0 ? (
                  <div className="rounded-[1.5rem] border border-secondary/30 bg-secondary/10 p-4 text-sm">
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="font-semibold text-amber-700 dark:text-amber-300">Upgrade for Unlimited</p>
                        <p className="mt-1 text-muted-foreground">
                          You’ve used today’s 3 free generations. Activate the {PREMIUM_PRICE} plan to keep ideating without a cap.
                        </p>
                      </div>
                      <Button variant="secondary" className="rounded-2xl" onClick={handleUpgrade} disabled={billingLoading}>
                        {billingLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CreditCard className="mr-2 h-4 w-4" />}
                        Upgrade now
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center gap-3 rounded-[1.5rem] border border-primary/20 bg-primary/10 px-4 py-3 text-sm text-primary dark:bg-primary/15">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>
                      {user
                        ? "Signed-in history auto-saves to Supabase. Favorites sync with your dashboard."
                        : "Guest mode is active. Sign in anytime to move history into Supabase and unlock billing."}
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>

            <section className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Output</p>
                  <h2 className="mt-2 text-3xl font-semibold">5 Reel ideas, ready to ship</h2>
                </div>
                <div className="flex items-center gap-2 rounded-full border border-border bg-background/70 px-4 py-2 text-sm text-muted-foreground">
                  <CopyCheck className="h-4 w-4 text-primary" />
                  One-click copy with thumbnails + hashtags
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
                {currentRecord?.ideas.map((idea, index) => (
                  <ReelCard
                    key={idea.id}
                    idea={idea}
                    index={index}
                    goal={currentRecord.goal}
                    style={currentRecord.style}
                    saved={currentRecord.saved}
                    onCopy={() => void handleCopyIdea(idea)}
                    onSave={handleSaveIdea}
                    onToggleFavorite={() => handleToggleFavorite(idea.id)}
                  />
                ))}
              </div>
            </section>

            <SiteFooter isUnlimited={isUnlimited} onUpgrade={handleUpgrade} onManageBilling={handleManageBilling} />
          </div>
        </section>
      </div>
    </div>
  );
}
