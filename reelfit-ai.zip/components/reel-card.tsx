"use client";

import { motion, useReducedMotion } from "framer-motion";
import { CheckCheck, Copy, Star } from "lucide-react";

import { ThumbnailMockup } from "@/components/thumbnail-mockup";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import type { GoalValue, ReelIdea, StyleValue } from "@/lib/types";
import { cn } from "@/lib/utils";

interface ReelCardProps {
  idea: ReelIdea;
  index: number;
  goal: GoalValue;
  style: StyleValue;
  saved: boolean;
  onCopy: () => void;
  onSave: () => void;
  onToggleFavorite: () => void;
}

export function ReelCard({
  idea,
  index,
  goal,
  style,
  saved,
  onCopy,
  onSave,
  onToggleFavorite
}: ReelCardProps) {
  const reduceMotion = useReducedMotion();

  return (
    <motion.div
      initial={reduceMotion ? false : { opacity: 0, y: 28 }}
      animate={reduceMotion ? undefined : { opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06, duration: 0.35, ease: "easeOut" }}
      whileHover={reduceMotion ? undefined : { scale: 1.02 }}
      className={cn(index === 0 && "md:col-span-2 xl:col-span-1")}
    >
      <Card className="group h-full overflow-hidden">
        <CardHeader className="space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-2">
              <Badge variant="outline">Idea {index + 1}</Badge>
              <CardTitle className="text-balance text-2xl leading-tight">{idea.hook}</CardTitle>
            </div>
            <button
              type="button"
              onClick={onToggleFavorite}
              aria-label={idea.favorite ? "Remove from favorites" : "Add to favorites"}
              className="rounded-full border border-border bg-background/70 p-2 transition hover:scale-[1.02] hover:bg-accent"
            >
              <Star className={cn("h-4 w-4", idea.favorite ? "fill-amber-400 text-amber-400" : "text-muted-foreground")} />
            </button>
          </div>
          <ThumbnailMockup goal={goal} style={style} label={idea.thumbnailLabel} />
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">Caption</p>
            <p className="text-sm leading-7 text-muted-foreground">{idea.caption}</p>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">Hashtags</p>
            <div className="flex flex-wrap gap-2">
              {idea.hashtags.map((hashtag) => (
                <Badge key={hashtag} variant="default" className="normal-case tracking-normal">
                  {hashtag}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-wrap items-center gap-3">
          <Button variant="default" className="flex-1 rounded-2xl" onClick={onCopy}>
            <Copy className="mr-2 h-4 w-4" />
            Copy All
          </Button>
          <Button variant="outline" className="flex-1 rounded-2xl" onClick={onSave}>
            <CheckCheck className="mr-2 h-4 w-4" />
            {saved ? "Saved to History" : "Save to History"}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
